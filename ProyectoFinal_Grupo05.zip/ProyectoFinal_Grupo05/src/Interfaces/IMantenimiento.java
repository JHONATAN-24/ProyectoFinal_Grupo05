
package Interfaces;

public interface IMantenimiento {
    
}
