
package Interfaces;

public interface IResultado {
    
}
