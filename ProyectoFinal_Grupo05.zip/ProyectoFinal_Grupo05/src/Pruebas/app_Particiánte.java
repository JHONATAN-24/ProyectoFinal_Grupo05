package Pruebas;



public class app_Particiánte {
    private String nombre;

    public app_Particiánte() {
    }

    public app_Particiánte(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
